create view Login_Household as
  select
    `CommunitySystem`.`Household`.`name`  AS `name`,
    `CommunitySystem`.`Household`.`phone` AS `phone`,
    `CommunitySystem`.`Login`.`password`  AS `password`
  from (`CommunitySystem`.`Household`
    join `CommunitySystem`.`Login` on ((`CommunitySystem`.`Login`.`phone` = `CommunitySystem`.`Household`.`phone`)));

