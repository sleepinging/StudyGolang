create view Login_Admin as
  select
    `CommunitySystem`.`Admin`.`name`     AS `name`,
    `CommunitySystem`.`Login`.`phone`    AS `phone`,
    `CommunitySystem`.`Login`.`password` AS `password`
  from (`CommunitySystem`.`Admin`
    join `CommunitySystem`.`Login` on ((`CommunitySystem`.`Login`.`phone` = `CommunitySystem`.`Admin`.`phone`)));

