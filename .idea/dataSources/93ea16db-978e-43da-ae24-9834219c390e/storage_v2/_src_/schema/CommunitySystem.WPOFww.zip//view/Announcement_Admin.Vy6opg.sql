create view Announcement_Admin as
  select
    `CommunitySystem`.`Admin`.`name`           AS `name`,
    `CommunitySystem`.`Announcement`.`time`    AS `time`,
    `CommunitySystem`.`Announcement`.`content` AS `content`
  from (`CommunitySystem`.`Admin`
    join `CommunitySystem`.`Announcement`
      on ((`CommunitySystem`.`Announcement`.`publisher` = `CommunitySystem`.`Admin`.`id`)));

